﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace JFLAP_MyApproach
{
    interface IDrawable
    {
        void Draw(Point location);
    }
}
